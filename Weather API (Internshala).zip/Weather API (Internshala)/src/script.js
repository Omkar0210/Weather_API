const recentSearches = JSON.parse(localStorage.getItem('recentSearches')) || [];
const recentSearchesDiv = document.getElementById('recent-searches');

function updateRecentSearches() {
    recentSearchesDiv.innerHTML = '';
    if (recentSearches.length > 0) {
        recentSearchesDiv.classList.remove('hidden');
        recentSearches.forEach(city => {
            const cityItem = document.createElement('div');
            cityItem.classList.add('p-2', 'hover:bg-gray-200', 'cursor-pointer');
            cityItem.textContent = city;
            cityItem.onclick = () => {
                document.getElementById('city-input').value = city;
                fetchWeather();
            };
            recentSearchesDiv.appendChild(cityItem);
        });
    } else {
        recentSearchesDiv.classList.add('hidden');
    }
}

function updateDateTime() {
    document.getElementById('date-time').textContent = new Date().toLocaleString();
}
setInterval(updateDateTime, 1000);

async function fetchWeather() {
    const apiKey = '2a4ecebe12fb55de6dfe9c6a78d5be8a';
    const city = document.getElementById('city-input').value;
    if (!city) return alert('Please enter a city name.');
    
    if (!recentSearches.includes(city)) {
        recentSearches.unshift(city);
        if (recentSearches.length > 5) recentSearches.pop();
        localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
    }
    updateRecentSearches();
    
    try {
        const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`);
        const weatherData = await weatherResponse.json();
        if (weatherData.cod !== 200) throw new Error(weatherData.message);
        
        displayWeather(weatherData);
        
        // Fetch 5-day forecast
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${apiKey}`);
        const forecastData = await forecastResponse.json();
        displayForecast(forecastData);
    } catch (error) {
        alert(`Error: ${error.message}`);
    }
}

function displayWeather(weatherData) {
    document.getElementById('weather-info').classList.remove('hidden');
    document.getElementById('city-name').textContent = weatherData.name;
    document.getElementById('temperature').textContent = `${weatherData.main.temp}°C`;
    document.getElementById('humidity').textContent = `Humidity: ${weatherData.main.humidity}%`;
    document.getElementById('wind-speed').textContent = `Wind Speed: ${weatherData.wind.speed} m/s`;
    document.getElementById('weather-icon').src = `http://openweathermap.org/img/w/${weatherData.weather[0].icon}.png`;
    document.getElementById('description').textContent = weatherData.weather[0].description;
}

function displayForecast(forecastData) {
    const forecastContainer = document.getElementById('forecast-container');
    forecastContainer.innerHTML = '';
    document.getElementById('forecast').classList.remove('hidden');
    
    const dailyData = {};
    forecastData.list.forEach(item => {
        const date = item.dt_txt.split(' ')[0];
        if (!dailyData[date]) {
            dailyData[date] = item;
        }
    });
    
    Object.values(dailyData).slice(0, 5).forEach(day => {
        const forecastCard = document.createElement('div');
        forecastCard.classList.add('p-4', 'bg-gray-100', 'rounded-md', 'text-center');
        forecastCard.innerHTML = `
            <p class="font-bold">${new Date(day.dt_txt).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</p>
            <img src="http://openweathermap.org/img/w/${day.weather[0].icon}.png" class="w-10 mx-auto">
            <p class="text-lg font-bold">${day.main.temp}°C</p>
            <p>☁ ${day.weather[0].description}</p>
            <p>💧 ${day.main.humidity}%</p>
            <p>🌬 ${day.wind.speed} m/s</p>
        `;
        forecastContainer.appendChild(forecastCard);
    });
}

// Update current location section 
function getCurrentLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                await fetchWeatherByCoords(lat, lon);
            },
            (error) => {
                alert("Error getting location: " + error.message);
            }
        );
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

async function fetchWeatherByCoords(lat, lon) {
    const apiKey = "2a4ecebe12fb55de6dfe9c6a78d5be8a";
    try {
        // Fetch current weather
        const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`);
        const weatherData = await weatherResponse.json();
        if (weatherData.cod !== 200) throw new Error(weatherData.message);
        displayWeather(weatherData);

        // Fetch 5-day forecast for current location
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`);
        const forecastData = await forecastResponse.json();
        displayForecast(forecastData);  // ✅ Ensures 5-day forecast is displayed for current location
    } catch (error) {
        alert("Failed to fetch weather data: " + error.message);
    }
}
updateRecentSearches();
